$(document).ready(function(){
    $("#follow").click(function(){
      $(".s2").show();
    });
    $("#following").click(function(){
     // $(".s2").hide();
     
    });
  });
  